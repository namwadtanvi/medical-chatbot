# Medical-chatbot
A simple web-based Medical Chatbot built using HTML, CSS, and JavaScript. The chatbot provides users with quick access to medical information and health tips.

Technologies
HTML for structure
CSS for styling
JavaScript for functionality
